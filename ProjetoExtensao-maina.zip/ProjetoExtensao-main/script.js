var cube = document.getElementById('cube');
var one = document.getElementById('1');
var two = document.getElementById('2');
var three = document.getElementById('3');
var four = document.getElementById('4');
var five = document.getElementById('5');
var six = document.getElementById('6');

var capturaFim;

var min = 1;
var max = 20; //maximo de voltas que o cubo pode dar
var atual = 1;


cube.onclick = function() {
  var xRand = 18180;
  var yRand = 720;
  xRand = xRand % 360;
  yRand = yRand % 360;  

  if(xRand == 0 && yRand == 0) 
  {
    atual = 1;
  } 
  else if(xRand == 0 && yRand == 90) 
  {
    atual = 4;
  }
  else if(xRand == 0 && yRand == 180) 
  {
    atual = 2;
  }
  else if(xRand == 0 && yRand == 270) 
  {
    atual = 3;
  }
  else if(xRand == 0 && yRand == 360) 
  {
    atual = 1;
  }
  else if(xRand == 90 && yRand == 0) 
  {
    atual = 6;
  }
  else if(xRand == 180 && yRand == 0) 
  {
    atual = 2;
  }
  else if(xRand == 270 && yRand == 0) 
  {
    atual = 5;
  }
  else if(xRand == 360 && yRand == 0) 
  {
    atual = 1;
  }

  console.log('O valor é ' + atual);




    
  cube.style.webkitTransform = 'rotateX('+xRand+'deg) rotateY('+yRand+'deg)'; //essa funcao que faz o cubo rodar
  cube.style.transform = 'rotateX('+xRand+'deg) rotateY('+yRand+'deg)';
}

function getRandom(max, min) {
  return (Math.floor(Math.random() * (max-min)) + min) * 90;
}


